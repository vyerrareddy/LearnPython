# Condition/Decission making

colour = 'red'

# if conditon
if colour == 'red':
    print ('Dangerous')
else:
    print('not red')

    
print('pgm completed successfully')

# if and else condition
if colour == 'red':
    print ('Dangerous')
else:
    print ('No dangerous')
print('pgm completed successfully')
    
# if , elif and else condition
if colour == 'red':
    print ('Dangerous')
elif colour == 'yellow':
    print ('Warning ')
    print('second line')
else:
    print('No dangerous')    
print('pgm completed successfully')

# Netsed if condions.

stclass = 2
stname='ram'
section = 'girl'

if stclass == 2:
    if section =='boy':
        if stname == 'ram':
            print('give the bix to him')
        else:
            print('no ram in class 2 and section boy')
            
    else:
        print('in class 2 no boys section')
else:
    print('no class 2 in school')     

