# define the numbers

a=20
b=40

print(a)
print(b)
# Number types - Interger, float, complex and long
x = 10
y = 2.50
#z=123456l
#z=2+4j
#type(x)

# adding of a,b & line continution  
a= 10
b=20
tot = a+b
print (tot)

sum1 = a+ \
    b
print(sum1)

a=20
b=3
a/b
a%b
a//b

# Assigmnet types - Below both statemtns are same 
a = a+b
a+=b

a=1
b=c=s=g=2
d,e,f = 3,4,'xyz'
print('a: ',a,'b: ',b,'c: ',c,'d: ',d,'e: ',e,'f: ',f,'s: ',s,'g: ',g)

#To find the variable type 
type (a)

#Number functions on Numbers
a=20
b=40
tot = a-b
abs(tot)
round(30.55)
max(3,1,56,99,3,4,6)
min(3,1,56,99,3,4,6)
x=100
y=4
pow(x,y)
p=x**y
print(p)

# Math functions
#import math as mt
import math
math.ceil(30.55)
math.floor(30.55)
math.sqrt(49)

# delete a Number / variable
x=1
print (x)
del x
print(x)
