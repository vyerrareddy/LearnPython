import os
dir()
os.getcwd()
os.chdir('C:\\Venkat\\Personal\\Trainings\\Python')
os.getcwd()

# modules

import modulefun, os

modulefun.add(10,20,30)

import modulefun as mf  # modulefun shpuld be available in the above mentioned path
mf.add(2,5,6)
mf.fib(50)
mf.a

print(mf.a)

from modulefun import add
add(2,5,6)

# Packages

import PYTHON_OCT2018
import functions

functions.

functions.add(11,11,11)

Functions.


modulefun.add(12,12,12)


.modulefun

md.add(4,5,6)
 